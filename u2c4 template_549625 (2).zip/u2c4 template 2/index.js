// write js code here corresponding to index.html
// You should add submit event on the form
